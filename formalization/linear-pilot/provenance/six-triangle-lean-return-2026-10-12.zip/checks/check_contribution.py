#!/usr/bin/env python3
"""Exact algebra and finite regression tests; NOT a Lean proof.

Python standard library only; all acceptance tests are explicit exceptions,
so -O does not disable them. The polynomial checks are universal formal
identities over Q. Rational examples do not establish quantification over R.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import permutations, product
from pathlib import Path
import hashlib
import json
import platform
import sys
import time

NAMES = ('x', 'y', 'z', 'w', 'c', 'b', 'u', 'v', 'S')
N = len(NAMES)
ZERO_EXP = (0,) * N


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


@dataclass
class Poly:
    """Small exact sparse polynomial, used only to check displayed identities."""
    terms: dict[tuple[int, ...], F]

    def __post_init__(self) -> None:
        self.terms = {m: F(a) for m, a in self.terms.items() if a}

    @staticmethod
    def const(a) -> 'Poly':
        return a if isinstance(a, Poly) else Poly({ZERO_EXP: F(a)})

    @staticmethod
    def var(i: int) -> 'Poly':
        m = list(ZERO_EXP)
        m[i] = 1
        return Poly({tuple(m): F(1)})

    def __add__(self, other) -> 'Poly':
        terms = dict(self.terms)
        for m, a in self.const(other).terms.items():
            terms[m] = terms.get(m, F(0)) + a
        return Poly(terms)

    __radd__ = __add__

    def __neg__(self) -> 'Poly':
        return Poly({m: -a for m, a in self.terms.items()})

    def __sub__(self, other) -> 'Poly':
        return self + -self.const(other)

    def __rsub__(self, other) -> 'Poly':
        return self.const(other) + -self

    def __mul__(self, other) -> 'Poly':
        terms = {}
        for m, a in self.terms.items():
            for n, b in self.const(other).terms.items():
                k = tuple(i + j for i, j in zip(m, n))
                terms[k] = terms.get(k, F(0)) + a*b
        return Poly(terms)

    __rmul__ = __mul__

    def __truediv__(self, other) -> 'Poly':
        return self * (1 / F(other))

    def __pow__(self, n: int) -> 'Poly':
        require(isinstance(n, int) and n >= 0, 'bad polynomial exponent')
        result = self.const(1)
        for _ in range(n):
            result = result * self
        return result


def q(p):
    x, y = p
    return x*x + x*y + y*y


def add(a, b):
    return a[0]+b[0], a[1]+b[1]


def sub(a, b):
    return a[0]-b[0], a[1]-b[1]


def cross(a, b):
    return a[0]*b[1]-a[1]*b[0]


def centroid(vs):
    return tuple(sum(p[i] for p in vs)/3 for i in (0, 1))


def rotate_cb(p, c, b):
    u, v = p
    return (c-b)*u-2*b*v, 2*b*u+(c+b)*v


def chart_cb(t):
    den = 1+3*t*t
    return (1-3*t*t)/den, 2*t/den


REFERENCE = ((F(-1,3), F(-1,3)), (F(2,3), F(-1,3)), (F(-1,3), F(2,3)))


def chart_vertices(center, t):
    c, b = chart_cb(t)
    return tuple(add(center, rotate_cb(p, c, b)) for p in REFERENCE)


def unit(vs):
    return all(q(sub(vs[i], vs[j])) == 1 for i in range(3) for j in range(i))


def chart_of_vertices(vs):
    """Construct the chart parameter and a permutation, with exact checks."""
    require(len(vs) == 3 and unit(vs), 'input is not an equilateral unit triple')
    original = tuple(vs)
    labels = [0, 1, 2]
    e = sub(vs[1], vs[0])
    f = sub(vs[2], vs[0])
    det = cross(e, f)
    require(det in (F(1), F(-1)), 'wrong determinant')
    reversed_order = det < 0
    if reversed_order:
        labels = [0, 2, 1]
    ordered = [original[i] for i in labels]
    e = sub(ordered[1], ordered[0])
    f = sub(ordered[2], ordered[0])
    require(f == (-e[1], e[0]+e[1]), 'positive completion failed')
    selected = None
    for k in range(3):
        klabels = labels[k:]+labels[:k]
        a, bpoint, cpoint = (original[i] for i in klabels)
        x, y = sub(bpoint, a)
        if x >= 0 and x+y >= 0:
            selected = k, klabels, a, x, y
            break
    require(selected is not None, 'closed sectors failed to cover')
    k, sigma, a, x, y = selected
    c, b = x+y/2, y/2
    require(c >= F(1,2), 'wrong cosine sector')
    require(c*c+3*b*b == 1, 'wrong rotation identity')
    t = b/(1+c)
    require(F(-1,3) <= t <= F(1,3), 'parameter outside CLOSED chart')
    require(chart_cb(t) == (c,b), 'inverse rational chart failed')
    center = centroid(original)
    reconstructed = chart_vertices(center, t)
    require(tuple(original[i] for i in sigma) == reconstructed,
            'vertex reconstruction changed original pose')
    require(set(original) == set(reconstructed), 'actual vertex ranges differ')
    return t, center, tuple(sigma), reversed_order, k


def weights(vs, p):
    e, f, d = sub(vs[1], vs[0]), sub(vs[2], vs[0]), sub(p, vs[0])
    determinant = cross(e, f)
    require(determinant != 0, 'degenerate input')
    l1, l2 = cross(d, f)/determinant, cross(e, d)/determinant
    return 1-l1-l2, l1, l2


def in_triangle(vs, p, strict=False):
    ws = weights(vs, p)
    return all(w > 0 if strict else w >= 0 for w in ws)


def frame1(p, S):
    u, v = p
    return v, S-u-v


def frame2(p, S):
    u, v = p
    return S-u-v, u


def polynomial_checks():
    x,y,z,w,c,b,u,v,S = [Poly.var(i) for i in range(N)]
    dot = 2*x*z+x*w+y*z+2*y*w
    det = x*w-y*z
    ids = {
        'lagrange': dot**2+3*det**2-4*q((x,y))*q((z,w)),
        'twice_inner_product': q((x,y))+q((z,w))-q((z-x,w-y))-dot,
        'reconstruct_z': 2*q((x,y))*z-(x*dot-(x+2*y)*det),
        'reconstruct_w': 2*q((x,y))*w-(y*dot+(2*x+y)*det),
        'cyclic_edge_1_preserves_Q': q((-x-y,x))-q((x,y)),
        'cyclic_edge_2_preserves_Q': q((y,-x-y))-q((x,y)),
        'physical_horizontal_cosine': (x+y/2)**2+3*(y/2)**2-q((x,y)),
        'sector_lower_bound_identity': (2*x+y)**2-q((x,y))-3*x*(x+y),
        'inverse_chart_denominator_numerator': (1+c)**2+3*b*b-2*(1+c)-(c*c+3*b*b-1),
        'inverse_chart_cosine_numerator': (1+c)**2-3*b*b-2*c*(1+c)+(c*c+3*b*b-1),
        'positive_completion_Q': q((-y,x+y))-q((x,y)),
        'negative_completion_Q': q((x+y,-x))-q((x,y)),
        'frame1_preserves_Q_differences': q((y,-x-y))-q((x,y)),
        'frame2_preserves_Q_differences': q((-x-y,x))-q((x,y)),
        'frame1_cut': sum(frame1((u,v), S))-(S-u),
        'frame2_cut': sum(frame2((u,v), S))-(S-v),
        'positive_center_cycle_u': x+((-x-y)-x)/3-(x-y)/3,
        'positive_center_cycle_v': y+((-x-y)+2*x)/3-(x+2*y)/3,
    }
    f3 = frame1(frame1(frame1((u,v),S),S),S)
    ids['frame1_cubed_u'] = f3[0]-u
    ids['frame1_cubed_v'] = f3[1]-v
    c0,b0 = x+y/2,y/2
    center = ((x-y)/3,(x+2*y)/3)
    positive = ((Poly.const(0),Poly.const(0)),(x,y),(-y,x+y))
    for i, ref in enumerate(REFERENCE):
        p = add(center,rotate_cb(ref,c0,b0))
        for j in range(2):
            ids[f'ordered_chart_vertex_{i}_{j}'] = p[j]-positive[i][j]
    for name, residual in ids.items():
        require(not residual.terms, f'polynomial identity failed: {name}')
    return {'count':len(ids),'normal_forms':{k:'0' for k in ids}}


def rational_checks():
    ts = sorted({F(p,q0) for q0 in range(1,13) for p in range(-36,37)} |
                {F(-1,3),F(1,3),F(-1),F(0),F(1)})
    centers = ((F(0),F(0)),(F(5,7),F(-11,13)),(F(-17,3),F(23,5)))
    totals, routes = 0, Counter()
    for c0 in centers:
        for t0 in ts:
            vs = chart_vertices(c0,t0)
            for perm in permutations(range(3)):
                pvs = tuple(vs[i] for i in perm)
                t, ctr, sigma, rev, k = chart_of_vertices(pvs)
                require(ctr == c0, 'centroid not retained')
                require(all(wi == F(1,3) for wi in weights(pvs,ctr)), 'centroid weights wrong')
                routes[f'reverse={rev},cycle={k}'] += 1
                totals += 1
        # The omitted stereographic pole, c=-1,b=0, must also be represented.
        pole = tuple(add(c0,rotate_cb(p,F(-1),F(0))) for p in REFERENCE)
        for perm in permutations(range(3)):
            chart_of_vertices(tuple(pole[i] for i in perm))
            totals += 1
    for t in (F(-1,3),F(1,3)):
        require(set(chart_vertices(centers[0],t)) ==
                set(chart_vertices(centers[0],-t)), 'endpoint sets differ')
    return {'input_parameters':len(ts),'translations':len(centers),
            'triples_checked':totals,'includes_stereographic_pole':True,
            'route_counts':dict(routes),'all_six_label_permutations':True}


def boundary_and_frame_checks():
    A = ((F(0),F(0)),(F(1),F(0)),(F(0),F(1)))
    J = ((F(0),F(1)),(F(1),F(0)),(F(1),F(1)))
    K = ((F(1),F(0)),(F(2),F(0)),(F(1),F(1)))
    contact = (F(1),F(0))
    for vs in (A,J,K):
        require(unit(vs), 'nonunit boundary fixture')
        require(in_triangle(vs,contact),'missing closed contact')
        require(in_triangle(vs,centroid(vs),strict=True),'empty interior fixture')
        chart_of_vertices(vs)
    require(max(p[0] for p in J) <= min(p[0] for p in K), 'J/K separator failed')
    require(min(sum(p) for p in J) == min(sum(p) for p in K) == 1,
            'boundary depth should be exactly one')
    tested = 0
    for S in (F(2),F(201,100),F(5,2),F(3)):
        corners = (A,((S,0),(S-1,0),(S-1,1)),((0,S),(0,S-1),(1,S-1)))
        corners = tuple(tuple((F(u),F(v)) for u,v in vs) for vs in corners)
        for vs in corners:
            require(unit(vs),'corner not unit')
            require(all(u>=0 and v>=0 and u+v<=S for u,v in vs),'corner escapes container')
        require(max(p[0] for p in corners[0]) <= min(p[0] for p in corners[1]),'A/B separation')
        require(max(p[1] for p in corners[0]) <= min(p[1] for p in corners[2]),'A/C separation')
        require(max(p[1] for p in corners[1]) <= min(p[1] for p in corners[2]),'B/C separation')
        require(set(frame1(p,S) for p in corners[1]) == set(A),'B corner frame incorrect')
        require(set(frame2(p,S) for p in corners[2]) == set(A),'C corner frame incorrect')
        for p in ((F(1,7),F(2,11)),(F(0),F(0)),(S,F(0)),(F(0),S)):
            require(frame1(frame1(frame1(p,S),S),S)==p,'frame cube failed')
            require(sum(frame1(p,S))==S-p[0],'original u cut failed')
            require(sum(frame2(p,S))==S-p[1],'original v cut failed')
            tested += 1
    arbitrary_side_tests = 0
    for S in (F(-1),F(0),F(1,2),F(1),F(3,2),F(2),F(3)):
        corners = (A,((S,F(0)),(S-1,F(0)),(S-1,F(1))),
                   ((F(0),S),(F(0),S-1),(F(1),S-1)))
        require(all(unit(vs) for vs in corners), 'corner unit property used S>=2')
        require(set(frame1(p,S) for p in corners[1]) == set(A), 'small-side B frame')
        require(set(frame2(p,S) for p in corners[2]) == set(A), 'small-side C frame')
        for p in ((F(1,7),F(2,11)),(F(-2),F(5)),(S,F(0))):
            require(frame1(frame1(frame1(p,S),S),S)==p,'all-side frame cube failed')
            require(sum(frame1(p,S))==S-p[0],'all-side u cut failed')
            require(sum(frame2(p,S))==S-p[1],'all-side v cut failed')
            arbitrary_side_tests += 1
    # The small-side forward proof must NOT assert mutual disjointness of corners.
    S = F(3,2)
    corner_B = ((S,F(0)),(S-1,F(0)),(S-1,F(1)))
    overlap_witness = (F(2,3),F(1,6))
    require(in_triangle(A,overlap_witness,strict=True) and
            in_triangle(corner_B,overlap_witness,strict=True),
            'S=3/2 inserted-corner overlap counterexample failed')
    return {'closed_contact_fixture':'J,K of supplied CornerBoundary.lean',
            'depths':['1','1'],'corner_sides':['2','201/100','5/2','3'],
            'frame_point_checks':tested,'all_side_frame_checks':arbitrary_side_tests,
            'all_side_parameters':['-1','0','1/2','1','3/2','2','3'],
            'insertion_below_two_counterexample':{'S':'3/2','point':['2/3','1/6']},
            'weak_separators_only':True}


def combinatorial_checks():
    hist = Counter()
    for offenders in product((None,0,1,2,3,4,5),repeat=3):
        deleted = {i for i in offenders if i is not None}
        good = sorted(set(range(6))-deleted)
        require(len(good)>=3,'fewer than three survivors')
        chosen = good[:3]
        require(len(set(chosen))==3,'survivor labels not distinct')
        require(all(i not in deleted for i in chosen),'an offender survived')
        hist[len(deleted)] += 1
    return {'all_admissible_relations_checked':7**3,'deleted_cardinality_histogram':dict(hist)}


def mutation_checks():
    out = []
    p = (F(0),F(0))
    # Incorrect inverse: t = b rather than b/(1+c).
    vs = chart_vertices(p,F(1,5))
    c,b = chart_cb(F(1,5))
    require(set(chart_vertices(p,b)) != set(vs),'bad inverse unexpectedly survived fixture')
    out.append('inverse t=b rejected by exact vertex-range mismatch')
    # Using a reversed labelled edge without changing to positive order.
    rev = (vs[0],vs[2],vs[1])
    x,y = sub(rev[1],rev[0])
    cb,beta = x+y/2,y/2
    wrong = chart_vertices(p,beta/(1+cb))
    require(set(wrong)!=set(rev),'missing handedness mutation survived')
    out.append('omitted handedness correction rejected')
    # Open-chart-only representation drops the permitted endpoint class.
    t,_,_,_,_ = chart_of_vertices(chart_vertices(p,F(1,3)))
    require(t in (F(-1,3),F(1,3)),'endpoint class unexpectedly became interior')
    out.append('strict-only parameter acceptance rejects a legal endpoint fixture')
    # Whole-set disjointness / strict closed cuts would reject legal contact.
    J = ((F(0),F(1)),(F(1),F(0)),(F(1),F(1)))
    require(any(sum(v)==1 for v in J),'no weak-cut counterexample')
    out.append('strict cut u+v>1 rejected by legal J boundary vertices')
    # Without capacity-one the union can remove all six pieces.
    bad_sets = ({0,1},{2,3},{4,5})
    require(set.union(*bad_sets)==set(range(6)),'capacity mutation fixture wrong')
    out.append('capacity-two premise fails survivor conclusion')
    return {'count':len(out),'kind':'exact Python counterexample tests, NOT Lean mutation runs','tests':out}


def main() -> int:
    started = time.perf_counter()
    report = {'status':'EXACT_CONTRIBUTION_CHECKS_PASSED',
              'python':platform.python_version(),
              'scope':'Polynomial identities and exact finite regression tests; no Lean compilation',
              'polynomial_identities':polynomial_checks(),
              'rational_chart':rational_checks(),
              'boundaries_and_frames':boundary_and_frame_checks(),
              'survivor_selection':combinatorial_checks(),
              'invalid_variants':mutation_checks()}
    report['elapsed_seconds'] = round(time.perf_counter()-started,3)
    report['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    dest = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('contribution_results.json')
    dest.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
