# Six-triangle Lean handoff: algebraic chart coverage and unchanged survivors

**Return date:** 12 October 2026  
**Baseline:** the uploaded `six-triangle-lean-pro-handoff-2026-10-12.zip`, with uncommitted v0.4 sources on top of `58edb942c38d46bf47024cb22de9fd3039646c9c`  
**Intended toolchain:** Lean **4.34.1**, Mathlib **d13f23b723b8a846827a245b89c10fc7d3f11612**  
**New Lean compilation:** **NOT RUN. Every supplied new Lean file is an uncompiled candidate.**

## 1. Main result and recommendation

Continue with the arbitrary-triple/chart bridge, but implement it **algebraically**, not through angles, `atan`, or a theorem classifying Euclidean isometries. A reversal of labels followed by a cyclic permutation puts a directed unit edge into one of three closed algebraic sectors. A rational inverse then supplies the existing parameter `t ∈ [-1/3, 1/3]`.

The mathematical argument below proves the stronger same-frame statement

```lean
∃ t : ℝ, (-1/3 : ℝ) ≤ t ∧ t ≤ (1/3 : ℝ) ∧
  Triangle.closedTriangle v =
    Triangle.unitTriangle (ChartCoverage.centroid v) t
```

from exactly `Packing.UnitEquilateral v`. The center is the **original arithmetic centroid**. Neither the triangle nor its coordinate frame moves. The proof identifies the actual filled sets, not just congruent shapes.

There is a useful further simplification:

> **Separate survivor extraction from insertion of the corner pieces. Extraction of three unchanged original survivors in `H(S)` does not require `S ≥ 2`. Only insertion of three mutually interior-disjoint corner pieces needs that inequality.**

I give a complete ordinary mathematical argument for this stronger extraction theorem, and an uncompiled candidate Lean implementation through `CornerFrames.original_survivors`. Its conclusion selects literal original vertex triples using an embedding `Fin 3 ↪ Fin 6`. There is no chart hypothesis, geometric-normalization premise, or `S ≥ 2` hypothesis in that candidate theorem.

For the requested simultaneous replacement at `S ≥ 2`, append the three explicit aligned corner pieces to those survivors. The supporting argument, including their weak separators and containment, is in §7. That final insertion/`Fin 6` assembly is described mathematically, **not implemented as a new Lean theorem** here.

This advances the geometric reduction. It does **not** supply the remaining Lean global cover, capture soundness, local rigidity, or complete optimality theorem.

## 2. What was actually done

| Work | Actual status in this session |
|---|---|
| Uploaded packet integrity | `VERIFY_PACKET.py` passed: 110 packet entries, 105 project entries. |
| Relevant source inspection | Read the instructions, unrestricted packing model, chart geometry, corner proof and boundary witnesses, relevant container and upper-bound sources, and the manuscript's corner section. |
| New mathematical work | Derived the algebraic coverage proof, closed-set clipping argument, all-side original-survivor reduction, and area-free small-side alternatives below. These are ordinary mathematical proofs, not kernel-checked results. |
| New Lean sources | Five candidate modules, plus an audit driver. **None compiled or elaborated here.** |
| New exact algebra checks | 26 polynomial identities reduced to zero by a standard-library sparse rational-polynomial checker. |
| New exact chart regressions | 9,720 exact rational vertex-triple reconstructions, including all six label permutations, three translations, both chart endpoints, and the omitted stereographic pole. |
| New finite survivor check | All 343 relations in which each of three corners has zero or one offender among six labels. Duplicate offenders at different corners are included. |
| Boundary/frame checks | Exact depth-one contact fixtures; corner-frame identities at small and negative sides as well as sides at least two; a strict-overlap witness for inserted corners at `S=3/2`. |
| New invalid-variant tests | Five exact Python counterexample tests. These are **not** new Lean mutation runs. |
| Supplied computational certificate | Replayed the supplied independent global and local consumers and the 28 packaged Python regression tests. Status: `COMPOSED_EXACT_REVIEW_PASSED`. |
| Existing 78 Lean audits / ten Lean mutations | **Not rerun.** Their recorded successful status remains baseline evidence, not a new check in this session. |

The runtime had Python 3.13.5 but no `lean` or `lake` executable on its path; a filesystem search also found no installation. Attempts to retrieve the pinned runtime/dependency information from GitHub through the execution environment failed at DNS resolution. No Lean installation or dependency cache was obtained. I did not silently substitute another Lean version.

The new files do not modify the baseline. The packet-integrity check passed again after this work. A final text-only scan found no `sorry`, `admit`, `axiom`, or `native_decide` tokens outside comments and strings in the new sources, confirmed the local `Pilot` import source files exist in the overlay or supplied snapshot, and matched all 47 new theorem declarations to the audit driver. **This is not a Lean parser, successful compilation, or an axiom audit.** See `checks/static_text_checks.json`.

### Exact certificate replay

The replay retained certificate SHA-256

```text
f8b2306312064ae083d91a97bd01d1669970685d1e3c0b71b3628f2ecfc773be
```

It checked 22,329 outer nodes, 328 captures, and 7,511 Farkas leaves. The separate local replay checked eight branches, 22 unavailable features, and 128 exact dual identities at radius `1/50`. All 28 packaged Python regression tests passed. The global consumer reported 355.348 elapsed seconds in this environment.

This was a fresh run of the **supplied consumers**, not a newly authored third independent global checker. Its successful status does not make those consumers, their analytic interpretation, or the global theorem into Lean proofs. See `checks/baseline_replay/result.json`, `global.json`, `local.json`, and their logs.

## 3. Algebraic coverage of arbitrary unit triples

Everything in this section is in the original oblique coordinates. Write

\[
Q(x,y)=x^2+xy+y^2.
\]

The supplied `Packing.squared_distance_eq_oblique` identifies this with the squared physical Cartesian length. Thus the unrestricted unit predicate gives exactly the three unit-edge equations used here.

### 3.1 Recover both possible third vertices

Let the original vertices be `A,B,C`, and write

\[
e=B-A=(x,y),\qquad f=C-A=(z,w).
\]

The hypotheses are

\[
Q(e)=Q(f)=Q(f-e)=1.
\]

Define

\[
d=2xz+xw+yz+2yw,\qquad D=xw-yz.
\]

Subtracting the third unit equation from the sum of the first two gives `d=1`. The polynomial identity

\[
d^2+3D^2=4Q(e)Q(f)
\]

then gives `D²=1`, hence `D=1` or `D=-1`. This also proves nondegeneracy; no degenerate filled triangle is being excluded by an extra assumption.

Two reconstruction identities are

\[
2Q(e)z=xd-(x+2y)D,
\]
\[
2Q(e)w=yd+(2x+y)D.
\]

Substituting `Q(e)=d=1` yields precisely

\[
(z,w)=(-y,x+y)\quad\text{or}\quad(z,w)=(x+y,-x).
\]

In the first case the vertices are positively ordered. In the second case, exchange **the labels** `B` and `C`. With the new edge `e'=C-A`, the other edge is `R₆₀e'`, because

\[
R_{60}(x+y,-x)=(x,y),\qquad R_{60}(r,s)=(-s,r+s).
\]

Nothing is reflected or rotated in physical space. The result is a triple of the form

\[
V(a,x,y)=\bigl(a,\ a+(x,y),\ a+(-y,x+y)\bigr),\qquad Q(x,y)=1.
\]

The original vertex range, convex hull, and arithmetic centroid are unchanged.

### 3.2 Choose one of three closed sectors by cyclic relabelling

The directed edges of this positively ordered triple are

\[
e_0=(x,y),\quad e_1=(-x-y,x),\quad e_2=(y,-x-y).
\]

Cyclically relabelling the vertices chooses any one of these as the first edge. For all real `x,y`, at least one of the following holds:

\[
\begin{aligned}
&x\ge0,\quad x+y\ge0;\\
&-x-y\ge0,\quad -y\ge0;\\
&y\ge0,\quad -x\ge0.
\end{aligned}
\]

A four-case sign proof is sufficient. If `x≥0` and `x+y≥0`, use the first sector. If `x≥0` but `x+y<0`, use the second. If `x<0` and `y≥0`, use the third. Otherwise both `x,y` are negative and the second works.

These are exactly the conditions that the selected edge `(X,Y)` satisfies

\[
X\ge0,\qquad X+Y\ge0.
\]

They are **closed** conditions. No tie-breaking proof involving strict inequalities is needed. Each cyclic edge still has squared length one by direct expansion of `Q`.

The center of `V(a,x,y)` is

\[
p=a+\left(\frac{x-y}{3},\frac{x+2y}{3}\right).
\]

When the edge is changed to `(-x-y,x)`, its new base point is `a+(x,y)`. Substituting both changes into the center formula gives exactly the same `p`. The second cyclic change follows by repetition. The Lean candidate records these center equalities explicitly.

### 3.3 Invert the supplied rational chart

For the selected edge, put

\[
c=X+Y/2,\qquad b=Y/2.
\]

Then

\[
c^2+3b^2=Q(X,Y)=1.
\]

The sector supplies `2X+Y≥0` and `X(X+Y)≥0`. The identity

\[
(2X+Y)^2=Q(X,Y)+3X(X+Y)\ge1
\]

therefore gives `2X+Y≥1`, i.e. `c≥1/2`. The sign is important: the square identity alone would not choose the positive branch.

It follows that `b²≤1/4`, hence `|b|≤1/2`. Define

\[
\boxed{t=\frac{b}{1+c}=\frac{Y}{2+2X+Y}.}
\]

The denominator is positive, since `1+c≥3/2`. Consequently

\[
-1/3\le t\le1/3.
\]

The two exact identities

\[
1+3\left(\frac b{1+c}\right)^2=\frac2{1+c},
\qquad
1-3\left(\frac b{1+c}\right)^2=\frac{2c}{1+c}
\]

follow from `c²+3b²=1`. They imply

\[
\operatorname{cosine}(t)=c,
\qquad
\operatorname{sineCoefficient}(t)=b.
\]

For the supplied oblique rotation matrix,

\[
R_t(1,0)=(c-b,2b)=(X,Y),
\]
\[
R_t(0,1)=(-2b,c+b)=(-Y,X+Y).
\]

Since the reference vertices sum to zero, adding their rotated versions to the original centroid `p` reconstructs the selected ordered original vertices exactly. Therefore, for an appropriate permutation `σ`,

\[
v_{\sigma(i)}=p+R_t r_i\quad(i=0,1,2).
\]

Equality of the **vertex ranges** gives equality of their **closed convex hulls**. Applying the Cartesian map gives equality of the actual physical filled triangles and therefore of their Cartesian interiors.

There is no common orientation assumption across the six pieces: apply this proof independently to each triple.

### 3.4 Endpoints and the stereographic pole

When `X=0`, the selected sector and `Q=1` give `(X,Y)=(0,1)` and `t=1/3`. When `X+Y=0`, they give `(X,Y)=(1,-1)` and `t=-1/3`. These are legal cases.

At a fixed centroid, the two endpoint triples are cyclic reorderings of

\[
(1/3,-2/3),\quad(1/3,1/3),\quad(-2/3,1/3).
\]

Thus both endpoints describe the same filled set. The representation is intentionally not unique.

The inverse formula is only used **after** choosing the sector. An initially supplied directed edge may have `c=-1`, where the unnormalized inverse would be undefined. Cyclic relabelling still gives a selected edge with `c≥1/2`. The exact tests explicitly include this omitted stereographic pole; they do not rely only on input triangles generated at finite parameters.

## 4. Interior nonemptiness and the closed-set cut

The determinant calculation above proves `triangleDet v ≠ 0`. At the arithmetic centroid, both non-base barycentric weights are exactly `1/3`; the remaining weight is also `1/3`. The supplied `Triangle.mem_interior_of_weights` then proves that this point belongs to the two-dimensional interior of the actual hull.

This is used to justify the following general lemma, not an additional hypothesis on packability:

> If a convex set `A` has nonempty interior, is contained in the wedge `u,v≥0`, and its interior is disjoint from the interior of the aligned corner, then **every point of A** satisfies `u+v≥1`.

First, any point of `interior A` has strictly positive `u` and `v`. For example, apply the supplied `HalfSpace.strict_bound_on_interior` to the nonzero functional `-u` and its bound `-u≤0` on `A`; similarly for `-v`.

If such an interior point also had `u+v<1`, it would lie in the open set

\[
\{u>0,\ v>0,\ u+v<1\},
\]

which is contained in the corner interior. That contradicts interior disjointness. Hence the entire interior of `A` lies in the closed halfspace `u+v≥1`.

Finally, convexity and nonempty interior give

\[
\overline{\operatorname{int}A}=\overline A.
\]

The closed halfspace contains that closure, hence contains `A`. The supplied `Corner.lean` already uses Mathlib's exact lemma

```lean
Convex.closure_interior_eq_closure_of_nonempty_interior
```

for a related closure extension; the candidate reuses that API pattern.

The converse is a weak-separator argument: if `A` is contained in `u+v≥1`, its interior is disjoint from the corner interior, whose points have sum strictly less than one.

**Do not strengthen the final cut to `u+v>1`.** The supplied depth-one `J` and `K` fixtures have legal closed contact and provide counterexamples to such a strengthening. The returned checks reproduce those fixtures with exact rational arithmetic.

## 5. Transport to all three corners without moving survivors

For any real `S`, define

\[
F_0(u,v)=(u,v),
\qquad
F_1(u,v)=(v,S-u-v),
\qquad
F_2(u,v)=(S-u-v,u).
\]

They cyclically permute the three barycentric coordinates `(S-u-v,u,v)`. In particular:

* `F₁²=F₂` and `F₁³=id`;
* each is an affine homeomorphism preserving the physical metric;
* each maps the container `ΔS` to itself;
* for a triangle, the transformed closed hull is exactly the hull of its transformed vertices.

For example the linear part of `F₁` maps `(x,y)` to `(y,-x-y)`, preserving `Q`. In the supplied rational rotation notation,

\[
F_1(p)=(0,S)+\operatorname{rotate}(-1,p).
\]

This is a convenient implementation shortcut: the existing metric and hull lemmas for `rotate` hold for **every** real parameter, so using `-1` here does not assert that it belongs to the root chart. Chart normalization is applied afterward to transformed arbitrary unit triples when needed.

Let

\[
C_k=F_k^{-1}(A_0),\qquad A_0=\{u,v\ge0,\ u+v\le1\}.
\]

These are the actual closed unit corner triangles. They may overlap each other or extend outside `ΔS` when `S` is small; neither fact harms survivor extraction.

A contained original triangle maps under each `F_k` into the origin wedge. Two original triangles that intrude into `interior C_k` would map to two unit triangles intruding into `interior A₀`. Apply the unrestricted corner-capacity lift and pull the overlap conclusion back through the homeomorphism. Thus at most one original piece can intrude into each corner.

Similarly, nonintrusion into corner `k` implies the closed cut `sum(F_k(p))≥1` at **every original point p**. The three cuts are

\[
u+v\ge1,\qquad S-u\ge1,\qquad S-v\ge1.
\]

Together with original containment, these are exactly

\[
0\le u,v\le S-1,\qquad1\le u+v\le S.
\]

They describe `H(S)` in the original coordinate frame.

**There has been no replacement of an original survivor by `F_k(survivor)` in the conclusion.** The maps are temporary proof devices. Their domain side is explicitly `S`; no target-side symmetry has been silently substituted. Subsequent normalization at `T` and its inverse-symmetry wall argument remain separate tasks.

## 6. Extract three literal original survivors, for every side

Fix the original six labelled triples `v : Fin 6 → VertexTriple`. Define

\[
\mathrm{bad}(k,i)\iff
\bigl(\operatorname{int}\operatorname{Hull}(v_i)
\cap\operatorname{int} C_k\bigr)\ne\varnothing.
\]

Capacity plus original pairwise nonoverlap proves that for fixed `k`, at most one label `i` is bad. The union of the three bad-label sets therefore has cardinality at most three. Its complement in `Fin 6` has at least three distinct labels. Choose an embedding

\[
f:\mathrm{Fin}\,3\hookrightarrow\mathrm{Fin}\,6
\]

whose image is in that complement.

Every selected piece `v(f j)` is exactly an original piece. It retains its unit-edge property and original pairwise interior disjointness. The closed-set cut argument puts its complete physical triangle inside `cartesian '' H(S)`.

The candidate conclusion is deliberately defined as

```lean
def OriginalSurvivors (S : ℝ) (v : Fin 6 → VertexTriple) : Prop :=
  ∃ f : Fin 3 ↪ Fin 6,
    (∀ j, UnitEquilateral (v (f j))) ∧
    (∀ j, physicalTriangle (v (f j)) ⊆
      cartesian '' Container.hexagon S) ∧
    (∀ i j, i ≠ j →
      Disjoint (interior (physicalTriangle (v (f i))))
        (interior (physicalTriangle (v (f j)))))
```

**No `S ≥ 2` was used in this proof.** We never needed the three `C_k` to be mutually disjoint or to be contained in the large triangle. Those properties become necessary only if they are inserted as packing pieces.

An original piece may intrude into more than one corner. Counting the **union** of bad labels is essential; the exact finite tests cover all such duplicate-offender cases. Empty corner-offender sets are also included. The code does not assume exactly three removals.

The all-side theorem is a strengthening of the manuscript's forward direction, not a claim that its stated `S ≥ 2` equivalence is wrong.

## 7. Simultaneous insertion at `S ≥ 2`

Once the three original survivors have been selected, use the prescribed corner vertex sets

\[
\begin{aligned}
A_0&=\{(0,0),(1,0),(0,1)\},\\
B_S&=\{(S,0),(S-1,0),(S-1,1)\},\\
C_S&=\{(0,S),(0,S-1),(1,S-1)\}.
\end{aligned}
\]

Take their closed convex hulls. Every edge has squared norm one. For `S≥2`, their vertices lie in `ΔS`, so the supplied vertex-to-hull containment theorem gives containment of the actual filled pieces.

The following weak separating inequalities prove mutual interior disjointness:

| Pair | First piece | Second piece |
|---|---|---|
| `A₀`, `B_S` | `u≤1` | `u≥S-1≥1` |
| `A₀`, `C_S` | `v≤1` | `v≥S-1≥1` |
| `B_S`, `C_S` | `v≤1` | `v≥S-1≥1` |

Weak inequalities are intentional: at `S=2` the corners legally touch.

Each survivor avoids the interior of every corner by its selection; alternatively use its three closed `H(S)` cuts as separators. Keep these three survivors and append the three corner triangles. They are six closed unit triangles with pairwise disjoint physical interiors in the same container. Discard any surplus old survivors. No continuous replacement motion is asserted or needed.

The insertion restriction is real. At `S=3/2`, the point `(2/3,1/6)` belongs strictly to both `A₀` and `B_S`. The exact test checks its positive barycentric weights in both triangles. Thus a formal theorem allowing insertion below two without further hypotheses would be false, even though the survivor-extraction proof remains valid.

**Remaining Lean work here:** construct the six-piece family and discharge its finite cases, including showing that the displayed corner hulls coincide with the inverse-image corner sets used during extraction. The equations and weak separators above give a direct route; no optimization or search certificate is needed.

## 8. Small sides: no area formalization is necessary

There are two useful options.

### Preferred extraction architecture

Use `CornerFrames.original_survivors` for every side. Then any later theorem about the selected triple has the original survivors available without first proving `S²≥6` or `S>2`.

As an ordinary mathematical check, this extraction already rules out a six-piece packing for `S≤2`: the survivors lie in `H(S)⊆H(2)`. The latter is the closed unit equilateral triangle with vertices `(1,0),(0,1),(1,1)`. The half-turn `(u,v)↦(1-u,1-v)` sends it to `A₀`. Two of the three survivors would become unit triangles contained in `A₀`, each with nonempty interior contained in its interior. They would both intrude into the origin corner while remaining interior-disjoint, contradicting unrestricted corner capacity. This additional corollary is **not implemented** in the returned Lean sources.

### Independent monotonicity wrapper

Even if the project retains a lower-bound proof only for `S≥2`, there is no need to formalize the area bound just to remove that premise from the final statement.

`Packable6` is monotone in the side: enlarge the container while retaining the same original vertex triples. If `S<2` and a packing existed, the same pieces would pack at side two. A restricted lower bound including `S=2` would then imply `T≤2`, contradicting the existing radical inequalities, which give `T>2`.

`LowerBoundReduction.lean` provides this small independent candidate module. Its lower-bound premise is an **explicit theorem argument**, not an asserted or hidden result:

```lean
(∀ S : ℝ, 2 ≤ S → Packable6 S → UpperBound.T ≤ S) →
  ∀ S : ℝ, Packable6 S → UpperBound.T ≤ S
```

It is not itself a proof of that premise or of optimality.

## 9. Returned code and integration order

All new Lean files are under `lean/`; none has been compiled.

| File | Intended role |
|---|---|
| `Pilot/ChartCoverage.lean` | Scalar determinant/completion lemmas, three-sector coverage, rational inverse, exact original-centroid hull representation, and derived nonempty interior. |
| `Pilot/UnrestrictedCorner.lean` | Lifts the existing corner theorem to unrestricted triples and proves the actual closed-set cut equivalence. |
| `Pilot/SurvivorSelection.lean` | Finite selection and the original-label conclusion type. Includes an explicitly conditional composition interface as an independently useful helper. |
| `Pilot/CornerFrames.lean` | Explicit affine homeomorphisms, metric/hull/interior transport, three-corner capacity and clipping, and the all-side `original_survivors` candidate. This discharges the geometric interface in the preceding module at the source-code level, **not at the kernel-checked level**. |
| `Pilot/LowerBoundReduction.lean` | Monotonicity and the independent small-side wrapper; no dependence on the new chart modules. |
| `ContributionAudit.lean` | Imports the full candidate path and requests axiom reports for all 47 new theorem declarations. This driver has **not** been run. |

I recommend first trying the independent small-side wrapper, then compiling the scalar part of `ChartCoverage.lean` incrementally. The meaningful milestone is `chart_coverage`; after that, the unrestricted corner lift is short. The full `CornerFrames` route contains more elaboration-sensitive image/coercion rewrites, so keep it a separate integration step.

Some finite-cardinality APIs were checked against Mathlib's public documentation (`Finset.card_le_one`, `Finset.card_union_le`, `Finset.card_univ_sdiff`, `Finset.two_lt_card`). Those documentation pages are **not a check against the exact pinned dependency**. In particular, compilation still needs to verify every import, coercion, tactic proof, and theorem-application shape in the actual snapshot.

Likely repair points are proof engineering rather than new proposed geometric premises: `field_simp` normal forms; `change`/function extensionality around vector notation; rewriting hull images through composed homeomorphisms; and finite-set coercions. If a step needs more than a syntactic/tactic repair, compare it with the mathematical proof here instead of adding a new chart, separation, or nondegeneracy hypothesis.

### Suggested local checks — NOT run here

This return is an **additive overlay**, not a standalone Lean project or a replacement for the supplied snapshot. Make a disposable copy of `project/formalization/linear-pilot/`, keeping its exact pinned dependencies. Overlay `lean/Pilot/*.lean` into that copy’s `Pilot/` and `lean/ContributionAudit.lean` into its project root. Then, from that copy:

```sh
lean --version
cat lean-toolchain
# Check lake-manifest.json still contains the exact supplied Mathlib revision.

lake build Pilot.LowerBoundReduction
lake build Pilot.ChartCoverage
lake build Pilot.UnrestrictedCorner
lake build Pilot.SurvivorSelection
lake build Pilot.CornerFrames
lake env lean ContributionAudit.lean
```

Require actual successful exit codes and axiom sets contained in `propext`, `Classical.choice`, and `Quot.sound`. Do not accept `sorryAx`, custom axioms, a successful wrapper that skipped the new modules, or a stale `.olean` produced from different source bytes. Then rerun the project's existing reproduction/mutation wrapper and add new theorem-specific negative tests.

The exact checks in this return are portable without Lean or third-party Python packages:

```sh
python3 -B -S -O VERIFY_RETURN.py
python3 -B -S -O checks/check_contribution.py /tmp/six_triangle_contribution_recheck.json
```

The first command checks return-file integrity only. The second tests the new executable construction and algebra; its optional output path preserves the recorded report rather than overwriting it. These checks do **not** parse or execute the Lean proof scripts and must not be used as a substitute for compilation.

## 10. Adversarial points and remaining uncertainty

**Wrong handedness.** Selecting an edge from a reversed labelled triple and treating it as positively ordered can put the third vertex on the wrong side. The determinant split and label exchange explicitly handle this. A returned exact mutation test catches omission of the correction.

**Wrong inverse or an initial chart assumption.** The inverse is `b/(1+c)`, not `b`, and it is applied after sector selection. The proof does not assume an arbitrary initial labelled edge already has `c≥1/2`. Exact tests include parameters well outside the root chart and the stereographic pole.

**Endpoint loss.** Open chart intervals would omit a legal orientation class. Both endpoints remain in every main statement. The returned endpoint fixture has the same exact vertex range at the two endpoints.

**Replacing filled hulls by vertex tests.** Vertex-range equality is used to prove hull equality. The clipping result extends from interiors to the complete convex set by closure. This is not an assertion that vertex nonoverlap proves triangle nonoverlap.

**Confusing contact with intrusion.** Offenders are defined by interior-interior intersection. Legal boundary contact does not count. Weak cuts and weak separators are retained. The depth-one fixtures remain counterexamples to inappropriate strict-cut or closed-contact variants.

**Duplicated offenders.** Three corners need not have three different offenders. The finite union count handles all cases, as does the exhaustive 343-case test.

**Losing the original frame.** The output family is `v ∘ f`, not a family merely congruent to it. The temporary corner maps occur only inside proofs; the selected physical vertices are not overwritten. Later target-side normalization and its inverse remain explicit obligations.

**Conflating extraction and insertion.** Extraction does not require the prescribed corners to fit mutually. Insertion does. The small-side overlap witness prevents silently treating the all-side extraction statement as an all-side replacement statement.

**Finite tests versus real quantification.** The 9,720 exact examples exercise branches, translations, labellings, endpoints, and the pole. They do not prove coverage of all real inputs. That coverage is supplied by the algebraic argument and must ultimately be checked through a successful Lean elaboration/kernel check.

**No end-to-end formal optimum yet.** Even successful compilation of all returned files would establish the chart bridge, corner lifts/cuts, and original-survivor reduction—not the full lower bound. The global orientation/centroid normalization, complete certificate interpretation and coverage, captures, local analytic rigidity, and target-wall/inverse-symmetry composition remain to be formalized. The insertion assembly is also not coded here.

I did not find a contradiction in the existing corner argument in the inspected scope. This was not a fresh adversarial audit of every manuscript section. The strongest concrete improvement is the proof decomposition: **exact algebraic chart coverage; all-side original survivor extraction; optional insertion at side at least two.**

## 11. Provenance and evidence locations

The source of baseline definitions and previously recorded results is the supplied snapshot, not GitHub HEAD or earlier conversations. In that snapshot, the key inspected files were:

```text
READ_THIS_FIRST.md
project/formalization/linear-pilot/Pilot/Packing.lean
project/formalization/linear-pilot/Pilot/Triangle.lean
project/formalization/linear-pilot/Pilot/Corner.lean
project/formalization/linear-pilot/Pilot/CornerBoundary.lean
project/formalization/linear-pilot/Pilot/HalfSpace.lean
project/formalization/linear-pilot/Pilot/Container.lean
project/formalization/linear-pilot/Pilot/UpperBound.lean
project/paper/main.tex, section "An analytic corner-replacement theorem"
project/tools/verify.py
```

The returned runtime record is `checks/environment.json`. New test results are `checks/contribution_results.json`, with executable source in `checks/check_contribution.py`. Fresh baseline replay reports and logs are in `checks/baseline_replay/`; the driver output is `logs/exact_replay_driver.log`. The return manifest binds the actual returned source and evidence files.

**Integration acceptance is intentionally delegated to independent local compilation and mathematical review. None of the uncompiled candidates should be described as a new Lean-verified theorem before those checks succeed.**
