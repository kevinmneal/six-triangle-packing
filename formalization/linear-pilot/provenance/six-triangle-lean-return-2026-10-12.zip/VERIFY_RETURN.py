#!/usr/bin/env python3
"""Verify return-file integrity only; not a mathematical or Lean proof checker."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys


def main() -> int:
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    problems = []
    for relative, expected in manifest['files'].items():
        path = root / relative
        if path.resolve().parent != root and root not in path.resolve().parents:
            problems.append(f'Unsafe manifest path: {relative}')
            continue
        if not path.is_file():
            problems.append(f'Missing file: {relative}')
            continue
        data = path.read_bytes()
        if len(data) != expected['bytes']:
            problems.append(f'Size mismatch: {relative}')
        actual = hashlib.sha256(data).hexdigest()
        if actual != expected['sha256']:
            problems.append(f'SHA-256 mismatch: {relative}')
    if problems:
        print('\n'.join(problems), file=sys.stderr)
        return 1
    print(f"RETURN_INTEGRITY_PASSED: {len(manifest['files'])} files.")
    print('Integrity only: no Lean compiler, axiom audit, or mathematical verifier was run.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
